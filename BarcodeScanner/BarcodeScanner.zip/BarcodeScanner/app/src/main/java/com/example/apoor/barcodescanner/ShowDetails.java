package com.example.apoor.barcodescanner;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ShowDetails extends AppCompatActivity {

  //  RequestQueue requestQueue;
    //String showUrl = "http://localhost/test.php?serialno=123";
     //TextView result;
  RequestQueue requestQueue;
  TextView txt;
    Button search;
    String number;
    ProgressDialog pd;
    Intent i = getIntent();
    String str = i.getStringExtra("scansno");

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_details);
        search = (Button)findViewById(R.id.button);
        txt = (TextView)findViewById(R.id.textView);
        pd = new ProgressDialog(ShowDetails.this);
        pd.setMessage("loading");
        pd.setCancelable(false);
        pd.setCanceledOnTouchOutside(false);

        requestQueue = Volley.newRequestQueue(getApplicationContext());
        //txt.setText(str);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               // String serialnumber = str.getText().toString().trim();

                getSqlDetails();
            }
        });

    }
    public void getSqlDetails() {

        String url= "http://192.168.1.104/test.php?serialno="+str;
        pd.show();
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        pd.hide();


                        try {

                            JSONArray jsonarray = new JSONArray(response);

                            for(int i=0; i < jsonarray.length(); i++) {

                                JSONObject jsonobject = jsonarray.getJSONObject(i);


                                //String id = jsonobject.getString("sno");
                                String name = jsonobject.getString("item_name");
                                String location = jsonobject.getString("location");
                                String staff = jsonobject.getString("staff");

                                txt.setText(" ID -"+str+"\n Name -"+name+"\n Location -"+location+"\n Staff -"+staff);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();


                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if(error != null){

                            Toast.makeText(getApplicationContext(), "Something went wrong.", Toast.LENGTH_LONG).show();
                        }
                    }
                }

        );

       // MySingleton.getInstance(getApplicationContext()).addToRequestQueue(stringRequest);
        requestQueue.add(stringRequest);
    }
}
